
		<div data-role="content" id="cacheMe" data-dom-cache="true"> 
					<ul data-role='listview' data-inset='true' >
				<li data-role='list-divider'>目录</li> 
				
				<li><a href='/lite/AboutUs' data-transition="flip">关于导师</a></li> 
				<li><a href='/lite/AboutCourse' data-transition="flip">培训课程</a></li> 
				<li><a href='/lite/Testimonial' data-transition="flip">留言评语</a></li> 
			</ul>
			<p style='font-size:20px;font-weight:bold;padding:5px;'>70％的职业人士每天努力的打拼，却得不到他们想要的结果。</p>
				<p style='font-size:18px;font-weight:bold;padding:5px;'>许多人渴望成功，透过上课希望能激励自己，提升自己，使生命更有动力。可是80％的课程只能让你知道，或是悟道，可是却做不到及得不到。
独特的90天“潜意识训练”不仅让你知道，悟道，而且做到及得到。
帮助你做到及得到，就是我们与众不同之处。
</p>

			 
<br/><img style='float:right;padding:10px;width:150px;height:150px; ' src='<?= $this->config->item('dir_path'); ?>/images/main2.png'  width = '80px'/>
	<p style="font-size:18px;font-weight:bold;padding:5px;color:#0B0B61"><b>独特的三大支柱，带领你迈向成功。</b></p>
	<ul>
			<li> <span class="geodot">＊</span>  独特的三大支柱，带领你迈向成功。
			<li> <span class="geodot">＊</span>  第二支柱：教练系统。
			<li> <span class="geodot">＊</span>  第三支柱：后续支持。
  </ul>
<br/>
	<br/>
	<p style='font-size:18px;font-weight:bold;padding:5px;'> 我们训练你的潜意识，自动化的帮助你达至成功。</p>
		<p style="font-size:18px;font-weight:bold;padding:5px;color:#0B0B61"><b>在90天里，你将体验：</b>  </p> 
<ul>    
		<li> <span class="geodot">～</span>  如何与潜意识沟通
		<li> <span class="geodot">～</span>  如何达至身心合一
		<li> <span class="geodot">～</span>  如何建立更和谐的内在与外在的关系
		<li> <span class="geodot">～</span>  如何发挥你的影响力。

</ul>   

		</div>
